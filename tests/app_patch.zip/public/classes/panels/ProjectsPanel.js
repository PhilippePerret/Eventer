class ProjectsPanel extends Panel {

  constructor(options = {}) {
    super({
      items: options.items || [],
      container: document.querySelector('#events'),
      modal: false,
      selectedIndex: options.selectedIndex || 0
    })

    this.lastDeletedProject = null
    UI.mode = 'projects'
  }

  open() {
    UI.panel = null
    UI.mode = 'projects'
    UI.renderFooter()
    this.render()
  }

  editableProperties() {
    return ['title']
  }

  mainProperty() {
    return 'title'
  }

  currentProject() {
    return this.currentItem()
  }

  async reload({ preserveSelection = true, selectedProjectId = null } = {}) {
    const previousId = selectedProjectId || (preserveSelection ? this.currentProject()?.id : null)

    const response = await fetch('/projects')
    if (!response.ok) return

    this.items = await response.json()

    if (previousId) {
      const index = this.items.findIndex(project => project.id === previousId)
      this.selectedIndex = index >= 0 ? index : Math.min(this.selectedIndex, Math.max(0, this.items.length - 1))
    } else {
      this.selectedIndex = 0
    }

    this.setSelectedIndex(this.selectedIndex)
    this.render()
  }

  render() {
    if (!this.container) return

    UI.panel = null
    UI.mode = 'projects'
    UI.renderFooter()

    this.container.innerHTML = ''
    this.container.classList.add('project-screen')

    const title = document.createElement('h1')
    title.className = 'project-title'
    title.textContent = 'Choisir un évènemencier'

    const list = document.createElement('div')
    list.className = 'project-list'

    this.container.append(title, list)

    this.items.forEach((project, index) => {
      list.appendChild(this.renderItem(project, index))
    })

    const undo = document.createElement('button')
    undo.type = 'button'
    undo.id = 'project-undo-delete'
    undo.className = 'project-undo hidden'
    undo.textContent = 'Annuler'
    undo.addEventListener('click', () => this.restoreDeletedProject())

    this.container.appendChild(undo)
  }

  renderItem(project, index) {
    const button = document.createElement('button')
    button.type = 'button'
    button.className = 'project-item'
    button.dataset.project = project.id

    this.selectRow(button, index)

    const name = document.createElement('span')
    name.className = 'project-name'
    name.dataset.editable = 'true'
    name.dataset.property = 'title'
    name.contentEditable = false
    name.spellcheck = false
    name.textContent = project.title || project.id

    const file = document.createElement('span')
    file.className = 'project-file'
    file.textContent = project.file

    button.append(name, ' ', file)
    return button
  }

  commitEditing(element) {
    const project = this.editingItem || this.currentProject()
    if (!project) return

    const title = element.textContent.trim()
    if (!title || title === project.title) {
      element.textContent = project.title || project.id
      return
    }

    project.title = title

    fetch(`/projects/${encodeURIComponent(project.id)}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title })
    }).catch(() => {})
  }

  async createItem() {
    this.stopEditing(true)

    const response = await fetch('/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    })

    if (!response.ok) return

    const data = await response.json()
    const createdId = data.id || data.project
    await this.reload({ preserveSelection: false, selectedProjectId: createdId })
    this.startEditing('title')
  }

  async deleteSelectedItem() {
    this.stopEditing(true)

    const project = this.currentProject()
    if (!project) return

    const response = await fetch(`/projects/${encodeURIComponent(project.id)}`, {
      method: 'DELETE'
    })

    if (!response.ok) return

    this.lastDeletedProject = project
    this.items.splice(this.selectedIndex, 1)
    this.setSelectedIndex(this.selectedIndex)
    this.render()

    const undo = document.querySelector('#project-undo-delete')
    if (undo) undo.classList.remove('hidden')
  }

  async restoreDeletedProject() {
    if (!this.lastDeletedProject) return

    const project = this.lastDeletedProject

    await fetch(`/projects/${encodeURIComponent(project.id)}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active: true })
    })

    this.lastDeletedProject = null
    await this.reload({ preserveSelection: false, selectedProjectId: project.id })
  }

  afterMoveItem() {
    this.persistOrder()
  }

  async persistOrder() {
    await fetch('/projects/order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ order: this.items.map(project => project.id) })
    })
  }

  openSelectedProject() {
    const project = this.currentProject()
    if (project) loadProject(project.id)
  }

  handleKeydown(e) {
    if (this.editing) {
      return this.handleEditingKeydown(e)
    }

    if (e.key === 'ArrowRight') {
      e.preventDefault()
      this.openSelectedProject()
      return true
    }

    return super.handleKeydown(e)
  }

}
